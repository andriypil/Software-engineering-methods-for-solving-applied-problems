function validate(n, W, weights, values) {
  if (weights.length !== n || values.length !== n) {
    throw new Error("Кількість не співпадає");
  }

  if (W <= 0) throw new Error("W має бути > 0");

  for (let x of [...weights, ...values]) {
    if (isNaN(x) || x < 0) {
      throw new Error("Некоректні дані");
    }
  }
}

function knapsack(weights, values, W) {
  let n = weights.length;
  let dp = Array.from({ length: n + 1 }, () => Array(W + 1).fill(0));

  for (let i = 1; i <= n; i++) {
    for (let w = 0; w <= W; w++) {
      if (weights[i - 1] <= w) {
        dp[i][w] = Math.max(
          dp[i - 1][w],
          dp[i - 1][w - weights[i - 1]] + values[i - 1]
        );
      } else {
        dp[i][w] = dp[i - 1][w];
      }
    }
  }

  return { dp, max: dp[n][W], items: restore(dp, weights, values, W) };
}

function restore(dp, weights, values, W) {
  let res = [];
  let i = weights.length;
  let w = W;

  while (i > 0 && w > 0) {
    if (dp[i][w] !== dp[i - 1][w]) {
      res.push(i);
      w -= weights[i - 1];
    }
    i--;
  }

  return res.reverse();
}

function drawTable(dp) {
  let html = "<table>";

  for (let row of dp) {
    html += "<tr>";
    for (let cell of row) {
      html += `<td>${cell}</td>`;
    }
    html += "</tr>";
  }

  html += "</table>";
  return html;
}

function run() {
  try {
    let n = parseInt(document.getElementById("n").value);
    let W = parseInt(document.getElementById("W").value);

    let weights = document.getElementById("weights").value.split(",").map(Number);
    let values = document.getElementById("values").value.split(",").map(Number);

    validate(n, W, weights, values);

    let result = knapsack(weights, values, W);

    document.getElementById("output").innerHTML =
      `<h2>Макс цінність: ${result.max}</h2>` +
      `<h3>Предмети: ${result.items.join(", ")}</h3>` +
      drawTable(result.dp);

  } catch (e) {
    alert(e.message);
  }
}
